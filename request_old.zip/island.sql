select * from BUDGET; 
select * from COMPANY ;
select * from DEPARTMENT ; 